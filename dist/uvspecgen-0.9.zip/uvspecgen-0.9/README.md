uvspecgen
=========

Generate UV-vis absorption spectrum from TDHF/TDDFT data in a Gaussian log file
